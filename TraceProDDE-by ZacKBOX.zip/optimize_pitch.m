%%  1. ��ʼ�� DDE ���� 
TP_COMMAND = ddeinit('TracePro','Scheme');

%%  2. ����׷���ͱ��� 
% ����׷��
% ddeexec(TP_COMMAND, '(raytrace:all-sources)');
% pause(4500);

% ������
irr_bmp = 'E:/data_tracepro/efficiency_0.48.bmp';
irr_txt = 'E:/data_tracepro/efficiency_0.48.txt';
irr1_bmp = 'E:/data_tracepro/efficiency1_0.48.bmp';
irr1_txt = 'E:/data_tracepro/efficiency1_0.48.txt';
ang_bmp = 'E:/data_tracepro/angle_0.48.bmp';
ang_txt = 'E:/data_tracepro/angle_0.48.txt';
uv_bmp = 'E:/data_tracepro/uv_0.48.bmp';
uv_txt = 'E:/data_tracepro/uv_0.48.txt';

% Irradiance
ddeexec(TP_COMMAND, '(edit:select (caddr (entity:faces (entity:get-by-name "plate"))))');
ddeexec(TP_COMMAND, '(analysis:irradiance-set-plot-quantities 0)');
ddeexec(TP_COMMAND, '(analysis:irradiance)');
ddeexec(TP_COMMAND, ['(analysis:irradiance-save "' irr_bmp '")']);
ddeexec(TP_COMMAND, ['(analysis:irradiance-save "' irr_txt '")']);
ddeexec(TP_COMMAND, '(analysis:irradiance-close)');

% Irradiance1
ddeexec(TP_COMMAND, '(edit:select (cadr (entity:faces (entity:get-by-name "ball"))))');
ddeexec(TP_COMMAND, '(analysis:irradiance-set-plot-quantities 0)');
ddeexec(TP_COMMAND, '(analysis:irradiance)');
ddeexec(TP_COMMAND, ['(analysis:irradiance-save "' irr1_bmp '")']);
ddeexec(TP_COMMAND, ['(analysis:irradiance-save "' irr1_txt '")']);
ddeexec(TP_COMMAND, '(analysis:irradiance-close)');

% Candela
ddeexec(TP_COMMAND, '(analysis:candela-rectangular-distribution)');
ddeexec(TP_COMMAND, ['(analysis:candela-save-bmp "rectangular-distribution" "' ang_bmp '")']);
ddeexec(TP_COMMAND, ['(analysis:candela-save-txt "rectangular-distribution" "' ang_txt '")']);
ddeexec(TP_COMMAND, '(analysis:candela-close "rectangular_dist")');

% CCT
ddeexec(TP_COMMAND, '(edit:select (caddr (entity:faces (entity:get-by-name "plate"))))');
ddeexec(TP_COMMAND, '(analysis:irradiance-set-plot-quantities 2)');
ddeexec(TP_COMMAND, '(analysis:irradiance)');
ddeexec(TP_COMMAND, ['(analysis:irradiance-save "' uv_bmp '")']);
ddeexec(TP_COMMAND, ['(analysis:irradiance-save "' uv_txt '")']);
ddeexec(TP_COMMAND, '(analysis:irradiance-close)');

fprintf('��������');

% ��������
ddeterm(TP_COMMAND);